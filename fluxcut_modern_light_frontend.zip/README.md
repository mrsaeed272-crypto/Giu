FluxCut — Modern Light frontend (GitHub Pages ready)

Files to upload to repo root:
- index.html
- styles.css
- script.js
- (optional) assets/ folder

Default API base URL is http://localhost:4000 — edit script.js if you have a hosted backend.
To deploy: upload files to GitHub repo root and enable Pages (main branch, root).
